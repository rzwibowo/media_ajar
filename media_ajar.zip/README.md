# media_ajar
Media pembelajaran pengenalan provinsi berbasis web

### Petunjuk Import Database MySQL
Langsung import saja, gausah bikin database dulu

### Petunjuk Export Database
* Pilih database
* Klik Export
* Pilih Opsi Custom <br>
  ![alt tag](http://i66.tinypic.com/120h6o5.jpg)
* Scroll ke bawah, pilih opsi Add CREATE DATABASE / USE statement<br>
  ![alt tag](http://i68.tinypic.com/2lay0hv.jpg)
* Selesai, klik GO
* Copy database ke dalam folder project sebelum commit dan push

### Layouting
Menggunakan kube, dokumentasi cek di https://imperavi.com/kube/docs/
